import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ICalendarEventsDemoWebPartProps {
    description: string;
}
export default class CalendarEventsDemoWebPart extends BaseClientSideWebPart<ICalendarEventsDemoWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CalendarEventsDemoWebPart.d.ts.map