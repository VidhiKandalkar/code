import * as React from 'react';
import { ICalendarEventsDemoProps } from './ICalendarEventsDemoProps';
import { ICalendarEventsDemoState } from './ICalendarEventsDemoState';
export default class CalendarEventsDemo extends React.Component<ICalendarEventsDemoProps, ICalendarEventsDemoState> {
    constructor(props: ICalendarEventsDemoProps);
    componentDidMount(): void;
    render(): React.ReactElement<ICalendarEventsDemoProps>;
}
//# sourceMappingURL=CalendarEventsDemo.d.ts.map