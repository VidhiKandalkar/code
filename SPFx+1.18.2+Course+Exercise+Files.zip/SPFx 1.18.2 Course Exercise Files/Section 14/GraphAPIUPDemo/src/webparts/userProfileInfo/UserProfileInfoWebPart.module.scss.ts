/* tslint:disable */
require("./UserProfileInfoWebPart.module.css");
const styles = {
  userProfileInfo: 'userProfileInfo_e213aeed',
  container: 'container_e213aeed',
  row: 'row_e213aeed',
  column: 'column_e213aeed',
  'ms-Grid': 'ms-Grid_e213aeed',
  title: 'title_e213aeed',
  subTitle: 'subTitle_e213aeed',
  description: 'description_e213aeed',
  button: 'button_e213aeed',
  label: 'label_e213aeed'
};

export default styles;
/* tslint:enable */