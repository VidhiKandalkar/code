export interface IUser {
    displayName: string;
    givenName: string;
    surname: string;
    mail: string;
    mobilePhone: string;
    userPrincipalName: string;
}
//# sourceMappingURL=IUser.d.ts.map