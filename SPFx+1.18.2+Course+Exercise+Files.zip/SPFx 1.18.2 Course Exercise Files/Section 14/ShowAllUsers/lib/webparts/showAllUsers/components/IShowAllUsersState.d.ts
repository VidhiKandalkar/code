import { IUser } from "./IUser";
export interface IShowAllUsersState {
    users: Array<IUser>;
    searchFor: string;
}
//# sourceMappingURL=IShowAllUsersState.d.ts.map