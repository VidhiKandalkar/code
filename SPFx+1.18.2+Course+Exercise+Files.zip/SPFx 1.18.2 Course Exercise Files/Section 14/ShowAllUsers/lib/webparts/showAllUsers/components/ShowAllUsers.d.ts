import * as React from 'react';
import { IShowAllUsersProps } from './IShowAllUsersProps';
import { IShowAllUsersState } from './IShowAllUsersState';
export default class ShowAllUsers extends React.Component<IShowAllUsersProps, IShowAllUsersState> {
    constructor(props: IShowAllUsersProps, state: IShowAllUsersState);
    componentDidMount(): void;
    _search: () => void;
    private _onSearchForChanged;
    private _getSearchForErrorMessage;
    fetchUserDetails(): void;
    render(): React.ReactElement<IShowAllUsersProps>;
}
//# sourceMappingURL=ShowAllUsers.d.ts.map