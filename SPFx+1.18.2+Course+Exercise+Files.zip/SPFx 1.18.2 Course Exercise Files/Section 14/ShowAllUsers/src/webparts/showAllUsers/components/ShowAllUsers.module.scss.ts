/* tslint:disable */
require("./ShowAllUsers.module.css");
const styles = {
  showAllUsers: 'showAllUsers_9c8d853a',
  container: 'container_9c8d853a',
  row: 'row_9c8d853a',
  column: 'column_9c8d853a',
  'ms-Grid': 'ms-Grid_9c8d853a',
  title: 'title_9c8d853a',
  subTitle: 'subTitle_9c8d853a',
  description: 'description_9c8d853a',
  button: 'button_9c8d853a',
  label: 'label_9c8d853a'
};

export default styles;
/* tslint:enable */