define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "SearchFor": "Type First Letter of UserName",
    "SearchForValidationErrorMessage": "Invalid value for 'Search for' field"
  }
});