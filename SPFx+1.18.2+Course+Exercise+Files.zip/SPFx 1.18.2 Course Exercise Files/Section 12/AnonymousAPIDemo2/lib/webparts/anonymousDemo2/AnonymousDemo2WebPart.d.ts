import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IAnonymousDemo2WebPartProps {
    description: string;
    apiURL: string;
    userID: string;
}
export default class AnonymousDemo2WebPart extends BaseClientSideWebPart<IAnonymousDemo2WebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected get disableReactivePropertyChanges(): boolean;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AnonymousDemo2WebPart.d.ts.map