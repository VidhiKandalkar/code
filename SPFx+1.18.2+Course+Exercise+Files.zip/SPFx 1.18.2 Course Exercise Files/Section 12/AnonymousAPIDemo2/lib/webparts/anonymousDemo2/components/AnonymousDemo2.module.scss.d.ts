declare const styles: {
    anonymousDemo2: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=AnonymousDemo2.module.scss.d.ts.map