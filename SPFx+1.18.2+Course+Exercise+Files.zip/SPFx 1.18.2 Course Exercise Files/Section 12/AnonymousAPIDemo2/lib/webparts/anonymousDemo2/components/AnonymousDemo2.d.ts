import * as React from 'react';
import { IAnonymousDemo2Props } from './IAnonymousDemo2Props';
import { IAnonymousDemo2State } from './IAnonymousDemo2State';
export default class AnonymousDemo2 extends React.Component<IAnonymousDemo2Props, IAnonymousDemo2State> {
    constructor(props: IAnonymousDemo2Props, state: IAnonymousDemo2State);
    getUserDetails(): Promise<any>;
    InvokeAPIAndSetDataIntoState(): void;
    componentDidMount(): void;
    componentDidUpdate(prevProps: IAnonymousDemo2Props, prevState: IAnonymousDemo2State, prevContext: any): void;
    render(): React.ReactElement<IAnonymousDemo2Props>;
}
//# sourceMappingURL=AnonymousDemo2.d.ts.map