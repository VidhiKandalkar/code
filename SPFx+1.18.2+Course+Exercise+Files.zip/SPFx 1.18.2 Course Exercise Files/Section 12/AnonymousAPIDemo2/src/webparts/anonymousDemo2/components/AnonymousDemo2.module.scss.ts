/* tslint:disable */
require("./AnonymousDemo2.module.css");
const styles = {
  anonymousDemo2: 'anonymousDemo2_6c5a4bee',
  container: 'container_6c5a4bee',
  row: 'row_6c5a4bee',
  column: 'column_6c5a4bee',
  'ms-Grid': 'ms-Grid_6c5a4bee',
  title: 'title_6c5a4bee',
  subTitle: 'subTitle_6c5a4bee',
  description: 'description_6c5a4bee',
  button: 'button_6c5a4bee',
  label: 'label_6c5a4bee'
};

export default styles;
/* tslint:enable */