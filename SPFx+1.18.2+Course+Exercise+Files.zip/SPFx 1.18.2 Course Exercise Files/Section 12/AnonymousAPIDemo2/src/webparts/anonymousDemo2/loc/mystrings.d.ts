declare interface IAnonymousDemo2WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AnonymousDemo2WebPartStrings' {
  const strings: IAnonymousDemo2WebPartStrings;
  export = strings;
}
