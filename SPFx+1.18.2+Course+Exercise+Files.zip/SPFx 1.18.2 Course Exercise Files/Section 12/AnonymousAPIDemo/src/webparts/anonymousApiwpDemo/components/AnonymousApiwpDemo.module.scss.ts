/* tslint:disable */
require("./AnonymousApiwpDemo.module.css");
const styles = {
  anonymousApiwpDemo: 'anonymousApiwpDemo_ae952902',
  container: 'container_ae952902',
  row: 'row_ae952902',
  column: 'column_ae952902',
  'ms-Grid': 'ms-Grid_ae952902',
  title: 'title_ae952902',
  subTitle: 'subTitle_ae952902',
  description: 'description_ae952902',
  button: 'button_ae952902',
  label: 'label_ae952902'
};

export default styles;
/* tslint:enable */