import * as React from 'react';
import { IAnonymousApiwpDemoProps } from './IAnonymousApiwpDemoProps';
export default class AnonymousApiwpDemo extends React.Component<IAnonymousApiwpDemoProps, {}> {
    render(): React.ReactElement<IAnonymousApiwpDemoProps>;
}
//# sourceMappingURL=AnonymousApiwpDemo.d.ts.map