export interface IAnonymousApiwpDemoProps {
    description: string;
    id: string;
    name: string;
    username: string;
    email: string;
    address: string;
    phone: string;
    website: string;
    company: string;
}
//# sourceMappingURL=IAnonymousApiwpDemoProps.d.ts.map