/* tslint:disable */
require("./ExtLibDemoWebPart.module.css");
const styles = {
  extLibDemo: 'extLibDemo_c02e74f3',
  container: 'container_c02e74f3',
  row: 'row_c02e74f3',
  column: 'column_c02e74f3',
  'ms-Grid': 'ms-Grid_c02e74f3',
  title: 'title_c02e74f3',
  subTitle: 'subTitle_c02e74f3',
  description: 'description_c02e74f3',
  button: 'button_c02e74f3',
  label: 'label_c02e74f3'
};

export default styles;
/* tslint:enable */