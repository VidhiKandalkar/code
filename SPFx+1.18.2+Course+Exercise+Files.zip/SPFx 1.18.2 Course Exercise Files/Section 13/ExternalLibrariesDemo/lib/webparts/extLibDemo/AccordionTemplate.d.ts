export default class AccordionTemplate {
    static templateHtml: string;
}
//# sourceMappingURL=AccordionTemplate.d.ts.map