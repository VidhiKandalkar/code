import * as React from 'react';
import { ICrudWithReactProps } from './ICrudWithReactProps';
import { ICrudWithReactState } from './ICrudWithReactState';
export default class CrudWithReact extends React.Component<ICrudWithReactProps, ICrudWithReactState> {
    private _selection;
    private _onItemsSelectionChanged;
    constructor(props: ICrudWithReactProps, state: ICrudWithReactState);
    private _getListItems;
    bindDetailsList(message: string): void;
    componentDidMount(): void;
    btnAdd_click: () => void;
    btnUpdate_click: () => void;
    btnDelete_click: () => void;
    private onVendorChange;
    private handleChange;
    render(): React.ReactElement<ICrudWithReactProps>;
}
//# sourceMappingURL=CrudWithReact.d.ts.map