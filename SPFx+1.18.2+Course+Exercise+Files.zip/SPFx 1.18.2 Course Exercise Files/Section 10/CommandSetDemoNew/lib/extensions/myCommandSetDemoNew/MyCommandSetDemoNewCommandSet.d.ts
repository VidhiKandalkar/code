import { BaseListViewCommandSet, IListViewCommandSetListViewUpdatedParameters, IListViewCommandSetExecuteEventParameters } from '@microsoft/sp-listview-extensibility';
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IMyCommandSetDemoNewCommandSetProperties {
    sampleTextOne: string;
    sampleTextTwo: string;
}
export default class MyCommandSetDemoNewCommandSet extends BaseListViewCommandSet<IMyCommandSetDemoNewCommandSetProperties> {
    onInit(): Promise<void>;
    onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void;
    onExecute(event: IListViewCommandSetExecuteEventParameters): void;
    private UpdateRemarks;
}
//# sourceMappingURL=MyCommandSetDemoNewCommandSet.d.ts.map