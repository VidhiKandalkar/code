define([], function() {
  return {
    "Title": "AcDemoNewApplicationCustomizer"
  }
});