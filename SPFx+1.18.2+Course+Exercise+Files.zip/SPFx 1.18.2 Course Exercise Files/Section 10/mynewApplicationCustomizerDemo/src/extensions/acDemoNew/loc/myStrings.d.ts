declare interface IAcDemoNewApplicationCustomizerStrings {
  Title: string;
}

declare module 'AcDemoNewApplicationCustomizerStrings' {
  const strings: IAcDemoNewApplicationCustomizerStrings;
  export = strings;
}
