/* tslint:disable */
require("./acDemoNew.module.css");
const styles = {
  acdemoapp: 'acdemoapp_e7154a5e',
  topPlaceholder: 'topPlaceholder_e7154a5e',
  bottomPlaceholder: 'bottomPlaceholder_e7154a5e'
};

export default styles;
/* tslint:enable */