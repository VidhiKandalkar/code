declare const styles: {
    acdemoapp: string;
    topPlaceholder: string;
    bottomPlaceholder: string;
};
export default styles;
//# sourceMappingURL=acDemoNew.module.scss.d.ts.map