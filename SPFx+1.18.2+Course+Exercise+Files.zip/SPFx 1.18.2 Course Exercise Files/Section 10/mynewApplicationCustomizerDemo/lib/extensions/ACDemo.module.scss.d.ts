declare const styles: {
    acdemoapp: string;
    topPlaceholder: string;
    bottomPlaceholder: string;
};
export default styles;
//# sourceMappingURL=ACDemo.module.scss.d.ts.map