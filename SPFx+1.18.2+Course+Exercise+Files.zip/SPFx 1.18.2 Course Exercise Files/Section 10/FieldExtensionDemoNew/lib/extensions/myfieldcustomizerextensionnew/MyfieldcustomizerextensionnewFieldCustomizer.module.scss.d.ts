declare const styles: {
    Myfieldcustomizerextensionnew: string;
    cell: string;
};
export default styles;
//# sourceMappingURL=MyfieldcustomizerextensionnewFieldCustomizer.module.scss.d.ts.map