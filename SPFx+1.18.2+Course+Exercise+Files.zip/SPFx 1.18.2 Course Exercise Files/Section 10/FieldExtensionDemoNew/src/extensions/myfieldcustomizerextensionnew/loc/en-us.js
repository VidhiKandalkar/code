define([], function() {
  return {
    "Title": "MyfieldcustomizerextensionnewFieldCustomizer"
  }
});