declare interface IMyfieldcustomizerextensionnewFieldCustomizerStrings {
  Title: string;
}

declare module 'MyfieldcustomizerextensionnewFieldCustomizerStrings' {
  const strings: IMyfieldcustomizerextensionnewFieldCustomizerStrings;
  export = strings;
}
