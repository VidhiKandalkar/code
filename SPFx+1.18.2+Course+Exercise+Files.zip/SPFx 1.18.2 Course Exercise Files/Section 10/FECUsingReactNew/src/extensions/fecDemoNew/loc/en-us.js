define([], function() {
  return {
    "Title": "FecDemoNewFieldCustomizer"
  }
});