declare interface IFecDemoNewFieldCustomizerStrings {
  Title: string;
}

declare module 'FecDemoNewFieldCustomizerStrings' {
  const strings: IFecDemoNewFieldCustomizerStrings;
  export = strings;
}
