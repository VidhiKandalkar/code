/* tslint:disable */
require("./FecDemoNew.module.css");
const styles = {
  FecDemo: 'FecDemo_c456d489',
  cell: 'cell_c456d489'
};

export default styles;
/* tslint:enable */