import { BaseFieldCustomizer, IFieldCustomizerCellEventParameters } from '@microsoft/sp-listview-extensibility';
/**
 * If your field customizer uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IFecDemoNewFieldCustomizerProperties {
    sampleText?: string;
}
export default class FecDemoNewFieldCustomizer extends BaseFieldCustomizer<IFecDemoNewFieldCustomizerProperties> {
    onInit(): Promise<void>;
    onRenderCell(event: IFieldCustomizerCellEventParameters): void;
    onDisposeCell(event: IFieldCustomizerCellEventParameters): void;
}
//# sourceMappingURL=FecDemoNewFieldCustomizer.d.ts.map