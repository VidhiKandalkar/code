declare const styles: {
    FecDemo: string;
    cell: string;
};
export default styles;
//# sourceMappingURL=FecDemoNew.module.scss.d.ts.map