import * as React from 'react';
export interface IFecDemoNewProps {
    text: string;
}
export default class FecDemoNew extends React.Component<IFecDemoNewProps, {}> {
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.ReactElement<{}>;
}
//# sourceMappingURL=FecDemoNew.d.ts.map