import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IMyIsolatedWebPartWebPartProps {
    description: string;
}
export default class MyIsolatedWebPartWebPart extends BaseClientSideWebPart<IMyIsolatedWebPartWebPartProps> {
    render(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MyIsolatedWebPartWebPart.d.ts.map