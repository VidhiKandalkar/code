/* tslint:disable */
require("./MyIsolatedWebPartWebPart.module.css");
const styles = {
  myIsolatedWebPart: 'myIsolatedWebPart_355c4ecf',
  container: 'container_355c4ecf',
  row: 'row_355c4ecf',
  column: 'column_355c4ecf',
  'ms-Grid': 'ms-Grid_355c4ecf',
  title: 'title_355c4ecf',
  subTitle: 'subTitle_355c4ecf',
  description: 'description_355c4ecf',
  button: 'button_355c4ecf',
  label: 'label_355c4ecf'
};

export default styles;
/* tslint:enable */