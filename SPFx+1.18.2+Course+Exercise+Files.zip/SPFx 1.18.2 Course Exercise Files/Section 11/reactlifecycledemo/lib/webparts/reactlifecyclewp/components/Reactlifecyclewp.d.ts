import * as React from 'react';
import { IReactlifecyclewpProps } from './IReactlifecyclewpProps';
export interface IReactlifecyclewpState {
    stageTitle: string;
}
export default class Reactlifecyclewp extends React.Component<IReactlifecyclewpProps, IReactlifecyclewpState> {
    constructor(props: IReactlifecyclewpProps, state: IReactlifecyclewpState);
    componentWillMount(): void;
    componentDidMount(): void;
    updateState(): void;
    render(): React.ReactElement<IReactlifecyclewpProps>;
    componentWillUnmount(): void;
}
//# sourceMappingURL=Reactlifecyclewp.d.ts.map