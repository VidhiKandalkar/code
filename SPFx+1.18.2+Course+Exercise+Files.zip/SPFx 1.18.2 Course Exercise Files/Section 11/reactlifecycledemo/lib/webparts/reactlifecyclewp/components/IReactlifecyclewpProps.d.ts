export interface IReactlifecyclewpProps {
    description: string;
}
//# sourceMappingURL=IReactlifecyclewpProps.d.ts.map