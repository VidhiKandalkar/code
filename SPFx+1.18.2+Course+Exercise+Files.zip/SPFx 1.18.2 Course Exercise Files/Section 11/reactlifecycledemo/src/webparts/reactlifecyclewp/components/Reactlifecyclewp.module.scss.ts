/* tslint:disable */
require("./Reactlifecyclewp.module.css");
const styles = {
  helloWorld: 'helloWorld_86f724f8',
  teams: 'teams_86f724f8',
  welcome: 'welcome_86f724f8',
  welcomeImage: 'welcomeImage_86f724f8',
  links: 'links_86f724f8'
};

export default styles;
/* tslint:enable */