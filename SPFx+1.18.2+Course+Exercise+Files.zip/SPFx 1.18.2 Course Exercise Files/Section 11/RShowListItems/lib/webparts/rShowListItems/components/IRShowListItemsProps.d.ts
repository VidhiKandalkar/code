export interface IRShowListItemsProps {
    description: string;
    websiteurl: string;
}
//# sourceMappingURL=IRShowListItemsProps.d.ts.map