import * as React from 'react';
import { IRShowListItemsProps } from './IRShowListItemsProps';
export interface IRShowListItemsWPState {
    listitems: [
        {
            "Title": "";
            "ID": "";
            "SoftwareName": "";
        }
    ];
}
export default class RShowListItems extends React.Component<IRShowListItemsProps, IRShowListItemsWPState> {
    static siteurl: string;
    constructor(props: IRShowListItemsProps, state: IRShowListItemsWPState);
    componentDidMount(): void;
    render(): React.ReactElement<IRShowListItemsProps>;
}
//# sourceMappingURL=RShowListItems.d.ts.map