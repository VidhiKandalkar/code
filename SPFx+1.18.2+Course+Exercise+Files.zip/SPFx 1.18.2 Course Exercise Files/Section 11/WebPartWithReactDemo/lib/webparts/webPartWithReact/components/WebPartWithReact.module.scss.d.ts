declare const styles: {
    helloWorld: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=WebPartWithReact.module.scss.d.ts.map