import * as React from 'react';
import { IWebPartWithReactProps } from './IWebPartWithReactProps';
export default class WebPartWithReact extends React.Component<IWebPartWithReactProps, {}> {
    render(): React.ReactElement<IWebPartWithReactProps>;
}
//# sourceMappingURL=WebPartWithReact.d.ts.map