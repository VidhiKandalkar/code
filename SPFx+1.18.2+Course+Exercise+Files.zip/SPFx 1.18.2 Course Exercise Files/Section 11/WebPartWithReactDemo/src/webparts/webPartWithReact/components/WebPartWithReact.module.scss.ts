/* tslint:disable */
require("./WebPartWithReact.module.css");
const styles = {
  helloWorld: 'helloWorld_7c8d17ba',
  teams: 'teams_7c8d17ba',
  welcome: 'welcome_7c8d17ba',
  welcomeImage: 'welcomeImage_7c8d17ba',
  links: 'links_7c8d17ba'
};

export default styles;
/* tslint:enable */